# sign_language > 2023-08-28 4:49pm
https://universe.roboflow.com/impact-fnqol/sign_language-gffwa

Provided by a Roboflow user
License: CC BY 4.0

